package animalchess.controller;

/**
 * A class to start the application
 */

public class Main {
    /**
     * This starts the application
     */
    public static void main(String[] args) {
        MainManager.open();
    }
}
