package animalchess.model;

/**
 * An interface that classifies if an animal is able to jump across the river
 */
public interface RiverJump {
}
