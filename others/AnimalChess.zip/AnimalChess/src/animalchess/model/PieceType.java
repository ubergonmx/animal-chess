package animalchess.model;

/**
 * Enumeration of different animals
 */
public enum PieceType {
    Mouse,
    Cat,
    Wolf,
    Dog,
    Leopard,
    Tiger,
    Lion,
    Elephant
}