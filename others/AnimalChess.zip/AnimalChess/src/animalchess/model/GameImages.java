package animalchess.model;

/**
 * A class used to get the images file path
 */

public class GameImages {
    // Terrain or Object Symbols
    public static final String RIVER = GameImages.class.getClassLoader().getResource("river.png").toString();
    public static final String ANIMAL_DEN = GameImages.class.getClassLoader().getResource("animalDen.png").toString();

    // Trap animals
    public static final String TRAP = GameImages.class.getClassLoader().getResource("trap.png").toString();
    public static final String MOUSE_TRAP = GameImages.class.getClassLoader().getResource("mouseTrap.png").toString();
    public static final String CAT_TRAP = GameImages.class.getClassLoader().getResource("catTrap.png").toString();
    public static final String WOLF_TRAP = GameImages.class.getClassLoader().getResource("wolfTrap.png").toString();
    public static final String DOG_TRAP = GameImages.class.getClassLoader().getResource("dogTrap.png").toString();
    public static final String LEOPARD_TRAP = GameImages.class.getClassLoader().getResource("leopardTrap.png").toString();
    public static final String TIGER_TRAP = GameImages.class.getClassLoader().getResource("tigerTrap.png").toString();
    public static final String LION_TRAP = GameImages.class.getClassLoader().getResource("lionTrap.png").toString();
    public static final String ELEPHANT_TRAP = GameImages.class.getClassLoader().getResource("elephantTrap.png").toString();

    // River Animals
    public static final String MOUSE_RIVER = GameImages.class.getClassLoader().getResource("mouseRiver.png").toString();
    public static final String ELEPHANT_RIVER = GameImages.class.getClassLoader().getResource("elephantRiver.png").toString();

    // Animals
    public static final String MOUSE = GameImages.class.getClassLoader().getResource("mouse.png").toString();
    public static final String CAT = GameImages.class.getClassLoader().getResource("cat.png").toString();
    public static final String WOLF = GameImages.class.getClassLoader().getResource("wolf.png").toString();
    public static final String DOG = GameImages.class.getClassLoader().getResource("dog.png").toString();
    public static final String LEOPARD = GameImages.class.getClassLoader().getResource("leopard.png").toString();
    public static final String TIGER = GameImages.class.getClassLoader().getResource("tiger.png").toString();
    public static final String LION = GameImages.class.getClassLoader().getResource("lion.png").toString();
    public static final String ELEPHANT = GameImages.class.getClassLoader().getResource("elephant.png").toString();
}