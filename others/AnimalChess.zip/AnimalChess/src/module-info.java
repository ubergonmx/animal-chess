module AnimalChess {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;

    opens animalchess.controller;
}